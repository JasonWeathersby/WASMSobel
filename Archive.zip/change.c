
#include<stdio.h>
#include<math.h>
#include<stdbool.h>
#include<stdlib.h>
#include<string.h>


#define WIDTH 600
#define HEIGHT 480
#define MAX(a,b) ((a) > (b) ? a : b)
#define MIN(a,b) ((a) < (b) ? a : b)


int grayData[WIDTH * HEIGHT];

int getPixel(int x, int y) {
    if (x < 0 || y < 0) return 0;
    if (x >= (WIDTH) || y >= (HEIGHT)) return 0;
    return (grayData[((WIDTH * y) + x)]);
}
void sobel(unsigned char * data, int width, int height) {


    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int goffset = ((WIDTH * y) + x) << 2; //multiply by 4
            int r = data[goffset];
            int g = data[goffset + 1];
            int b = data[goffset + 2];

            //int avg = (r + g + b) / 3;
            //The line below is a quick way to divide rgb values (range 0->768) by 3 
            //Shifting by 10 ( is dividing 1024 ) and then 341/1024 = 1/3 
            //(int8 + int8 + int8) * 341 fits in 32 bits
            //the max of that is 255 * 3 * 341 = 260,865 which is 19 bits
            int avg = (r + g + b) * 341 >> 10;
            grayData[((WIDTH * y) + x)] = avg;

            int doffset = ((WIDTH * y) + x) << 2;
            data[doffset] = avg;
            data[doffset + 1] = avg;
            data[doffset + 2] = avg;
            data[doffset + 3] = 255;

        }
    }

    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int newX;
            int newY;
            if ((x <= 0 || x >= width - 1) || (y <= 0 || y >= height - 1)) {
                newX = 0;
                newY = 0;
            } else {
                newX = (
                    (-1 * getPixel(x - 1, y - 1)) +
                    (getPixel(x + 1, y - 1)) +
                    (-1 * (getPixel(x - 1, y) << 1)) +
                    (getPixel(x + 1, y) << 1) +
                    (-1 * getPixel(x - 1, y + 1)) +
                    (getPixel(x + 1, y + 1))
                );
                newY = (
                    (-1 * getPixel(x - 1, y - 1)) +
                    (-1 * (getPixel(x, y - 1) << 1)) +
                    (-1 * getPixel(x + 1, y - 1)) +
                    (getPixel(x - 1, y + 1)) +
                    (getPixel(x, y + 1) << 1) +
                    (getPixel(x + 1, y + 1))
                );
            }
            //int tst = (pixelX * pixelX) + (pixelY * pixelY);
            //if( tst < 0 )tst =0;
            int mag = sqrt((newX * newX) + (newY * newY)); //floor(sqrtf(tst)); //this line is taking about 2ms
            if (mag > 255) mag = 255;
            int offset = ((WIDTH * y) + x) << 2; //multiply by 4
            data[offset] = 255 - mag;
            data[offset + 1] = 255 - mag;
            data[offset + 2] = 255 - mag;
            data[offset + 3] = 255;



        }
    }
}


void change(unsigned char * data, int cols, int rows) {
    sobel(data, cols, rows);

}











